EGGNOGG+ (ALPHA)
by MADGARDEN

CONTROLS:

Two players can play on the same keyboard, or using joysticks:

Player1 - Joystick 1, or keyboard
	- Move/aim: WASD
	- Attack: LCTRL or B
	- Jump: LSHIFT or SPACE or V

Player2 - Joystick 2, or keyboard
	- Move/aim: CURSORS
	- Attack: PERIOD
	- Jump: COMMA

CONTROLS can be reconfigured from the GEAR menu on the title screen:

MOVE by holding left or right.

AIM your sword for stabbing, blocking, and throwing using UP/DOWN
controls. If an opponent's attack comes in low, middle, or high, you
can move your sword to block at the same height. This also works for
bare-fisted combat (though not against swords!) The player
will punch when in close, or otherwise kick (for more damage).

RUNNING occurs once you are out of duelling range, or you can
force running by pressing DOWN/LEFT or DOWN/RIGHT and JUMP.

THROW while running by HOLDING the ATTACK button. You
can throw it at various different angles, bounce it off of stuff. It
might even bounce back and impale you. Good times.

FLECHE attacks are executed if you TAP the ATTACK button while RUNNING.

DUCK by pressing DOWN and JUMP. If performed while running, you will
slide. You'll pick up a sword in either case if you are empty-handed.

EXTRA INFO:

It is possible to offbalance your opponent during close-range sword
fighting. Attack while doing a blade PRESS. Beware, your opponent can
reverse the press and cause you to be offbalanced.

You may also disarm your opponent in various ways...

At the title screen, you can change your hero's colours. You can also
change your opponent's colours. HEH HEH HEH.

You can change the window size using F1. Toggle fullscreen with F11.
Pressing F5 will restart a game immediately.

Check out @madgarden on Twitter, on our website at
http://www.madgarden.net, or email at info@madgarden.net

Good stabbing... seeya!
